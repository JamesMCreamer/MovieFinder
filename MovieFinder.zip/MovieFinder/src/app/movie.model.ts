export class Movie {
    constructor(
        public title:string,
        public year:string,
        public director:string) {
        }
}